"""
SAM CLI version
"""

__version__ = "1.131.0"
